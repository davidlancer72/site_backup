from flask import Flask, render_template, send_from_directory

app = Flask(__name__, static_folder='static')


@app.route('/')
def index():
  return render_template('index.html')


@app.route('/hidden_content/<path:filename>')
def serve_hidden_content(filename):
  return send_from_directory('hidden_content', filename)


@app.route('/robots.txt')
def get_robots_txt():
  return send_from_directory("static", "robots.txt")


if __name__ == '__main__':
  app.run(host='0.0.0.0', port=80)
